import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { Server, Socket } from 'socket.io';
import dotenv from 'dotenv';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOMS_FILE = path.join(__dirname, 'rooms-store.json');

function loadRooms(): Record<string, Room> {
  try {
    if (fs.existsSync(ROOMS_FILE)) {
      const data = fs.readFileSync(ROOMS_FILE, 'utf-8');
      const parsed = JSON.parse(data);
      if (parsed && typeof parsed === 'object') {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error loading rooms-store.json:', e);
  }
  return {};
}

function saveRooms(roomsObj: Record<string, Room>) {
  try {
    const cleanObj: Record<string, any> = {};
    for (const [code, r] of Object.entries(roomsObj)) {
      cleanObj[code] = {
        code: r.code,
        name: r.name,
        hostId: r.hostId,
        duration: r.duration,
        status: r.status,
        startedAt: r.startedAt,
        createdAt: r.createdAt,
        players: r.players,
      };
    }
    fs.writeFileSync(ROOMS_FILE, JSON.stringify(cleanObj, null, 2), 'utf-8');
  } catch (e) {
    console.error('Error saving rooms-store.json:', e);
  }
}

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

const PORT = process.env.PORT || 3000;

app.use(express.json());

interface PlayerState {
  id: string;
  username: string;
  score: number;
  combo: number;
  maxCombo: number;
  reps: number;
  invalidReps: number;
  isReady: boolean;
  isCalibrated: boolean;
  dArm: number;
  dTorso: number;
  latencyMs?: number;
}

interface Room {
  code: string;
  name: string;
  hostId: string;
  duration: number;
  status: 'lobby' | 'calibrating' | 'countdown' | 'playing' | 'gameover';
  startedAt?: number;
  createdAt: number;
  players: Record<string, PlayerState>;
  emptyTimer?: NodeJS.Timeout;
}

function broadcastRoomList() {
  const rooms = loadRooms();
  const activeList = Object.values(rooms).map((r) => ({
    code: r.code,
    name: r.name || `Phòng của ${r.players[r.hostId]?.username || 'Chủ Phòng'}`,
    hostUsername: r.players[r.hostId]?.username || 'Chủ Phòng',
    playerCount: Object.keys(r.players).length,
    status: r.status,
    duration: r.duration,
    createdAt: r.createdAt,
  }));
  io.emit('rooms:list_updated', { rooms: activeList });
}

app.get('/api/rooms', (_req, res) => {
  const rooms = loadRooms();
  const activeList = Object.values(rooms).map((r) => ({
    code: r.code,
    name: r.name || `Phòng của ${r.players[r.hostId]?.username || 'Chủ Phòng'}`,
    hostUsername: r.players[r.hostId]?.username || 'Chủ Phòng',
    playerCount: Object.keys(r.players).length,
    status: r.status,
    duration: r.duration,
    createdAt: r.createdAt,
  }));
  res.json({ rooms: activeList });
});

function generateRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

io.on('connection', (socket: Socket) => {
  let currentRoomCode: string | null = null;

  const leaveCurrentRoom = (isExplicitLeave = false) => {
    const rooms = loadRooms();
    if (currentRoomCode && rooms[currentRoomCode]) {
      const room = rooms[currentRoomCode];
      delete room.players[socket.id];
      socket.leave(currentRoomCode);

      const remainingPlayers = Object.keys(room.players);
      if (remainingPlayers.length === 0) {
        if (room.emptyTimer) clearTimeout(room.emptyTimer);

        if (isExplicitLeave || room.status !== 'lobby') {
          delete rooms[currentRoomCode];
          console.log(`[Room Purge] Room ${currentRoomCode} deleted immediately (0 players left)`);
          saveRooms(rooms);
          broadcastRoomList();
        } else {
          const roomToPurge = currentRoomCode;
          room.emptyTimer = setTimeout(() => {
            const rMap = loadRooms();
            if (rMap[roomToPurge] && Object.keys(rMap[roomToPurge].players).length === 0) {
              delete rMap[roomToPurge];
              console.log(`[Room Purge] Grace period expired, room ${roomToPurge} deleted.`);
              saveRooms(rMap);
              broadcastRoomList();
            }
          }, 60000);
          saveRooms(rooms);
        }
      } else {
        if (room.status === 'playing' || room.status === 'countdown') {
          room.status = 'gameover';
          io.to(currentRoomCode).emit('match:opponent_forfeit', {
            leaverId: socket.id,
            winnerId: remainingPlayers[0],
            message: 'Đối thủ đã thoát phòng! Bạn lập tức giành CHIẾN THẮNG TUYỆT ĐỐI (Victory by Forfeit)!',
          });
        }

        const wasHost = room.hostId === socket.id;
        if (wasHost || !room.players[room.hostId]) {
          const newHostId = remainingPlayers[0];
          room.hostId = newHostId;
          const newHostUsername = room.players[newHostId]?.username || 'Chủ Phòng';
          console.log(`[Host Transfer] Room ${currentRoomCode}: Host ${socket.id} left. Transferred host to ${newHostId} (${newHostUsername})`);

          io.to(currentRoomCode).emit('room:host_transferred', {
            newHostId,
            newHostUsername,
            message: `Chủ phòng đã thoát. Bạn hiện là Chủ Phòng mới và có quyền Bắt Đầu trận đấu!`,
          });
        }

        saveRooms(rooms);
        io.to(currentRoomCode).emit('room:updated', { room });
        io.to(currentRoomCode).emit('room:player_left', { playerId: socket.id });
        broadcastRoomList();
      }
      currentRoomCode = null;
    }
  };

  socket.on('room:leave', () => {
    leaveCurrentRoom(true);
  });

  socket.on('rooms:list', () => {
    const rooms = loadRooms();
    const list = Object.values(rooms).map((r) => ({
      code: r.code,
      name: r.name || `Phòng của ${r.players[r.hostId]?.username || 'Chủ Phòng'}`,
      hostUsername: r.players[r.hostId]?.username || 'Chủ Phòng',
      playerCount: Object.keys(r.players).length,
      status: r.status,
      duration: r.duration,
      createdAt: r.createdAt,
    }));
    socket.emit('rooms:list_result', { rooms: list });
  });

  socket.on('room:reconnect', ({
    code,
    username,
    isHost,
    duration = 30,
    roomName,
  }: {
    code: string;
    username: string;
    isHost?: boolean;
    duration?: number;
    roomName?: string;
  }) => {
    const formattedCode = (code || '').toUpperCase().trim().replace(/[^A-Z0-9]/g, '');
    if (!formattedCode || formattedCode.length !== 4) return;

    const rooms = loadRooms();
    let room = rooms[formattedCode];
    if (!room) {
      room = {
        code: formattedCode,
        name: roomName || `Phòng đấu ${formattedCode}`,
        hostId: socket.id,
        duration,
        status: 'lobby',
        createdAt: Date.now(),
        players: {
          [socket.id]: {
            id: socket.id,
            username: username || 'Chủ Phòng',
            score: 0,
            combo: 0,
            maxCombo: 0,
            reps: 0,
            invalidReps: 0,
            isReady: false,
            isCalibrated: false,
            dArm: 0,
            dTorso: 0,
          },
        },
      };
      rooms[formattedCode] = room;
    } else {
      if (room.emptyTimer) {
        clearTimeout(room.emptyTimer);
        delete room.emptyTimer;
      }
      // If room has no active host or host is not in room.players, assign this user as host
      if (!room.players[room.hostId] || Object.keys(room.players).length === 0) {
        room.hostId = socket.id;
      }
      room.players[socket.id] = {
        id: socket.id,
        username: username || (room.hostId === socket.id ? 'Chủ Phòng' : 'Đối Thủ (P2)'),
        score: 0,
        combo: 0,
        maxCombo: 0,
        reps: 0,
        invalidReps: 0,
        isReady: false,
        isCalibrated: false,
        dArm: 0,
        dTorso: 0,
      };
    }

    saveRooms(rooms);
    currentRoomCode = formattedCode;
    socket.join(formattedCode);
    socket.emit('room:joined', { room, playerId: socket.id, isHost: room.hostId === socket.id });
    io.to(formattedCode).emit('room:updated', { room });
    broadcastRoomList();
  });

  socket.on('room:create', ({
    username,
    duration = 30,
    roomName,
  }: {
    username: string;
    duration: number;
    roomName?: string;
  }) => {
    leaveCurrentRoom(true);

    const rooms = loadRooms();
    let code = generateRoomCode();
    while (rooms[code]) {
      code = generateRoomCode();
    }

    const hostName = (username || '').trim() || 'Chủ Phòng';
    const finalRoomName = (roomName || '').trim() || `Phòng của ${hostName}`;

    const room: Room = {
      code,
      name: finalRoomName,
      hostId: socket.id,
      duration,
      status: 'lobby',
      createdAt: Date.now(),
      players: {
        [socket.id]: {
          id: socket.id,
          username: hostName,
          score: 0,
          combo: 0,
          maxCombo: 0,
          reps: 0,
          invalidReps: 0,
          isReady: false,
          isCalibrated: false,
          dArm: 0,
          dTorso: 0,
        },
      },
    };

    rooms[code] = room;
    saveRooms(rooms);
    currentRoomCode = code;
    socket.join(code);

    socket.emit('room:created', { room, playerId: socket.id });
    broadcastRoomList();
  });

  socket.on('room:join', ({ code, username }: { code: string; username: string }) => {
    leaveCurrentRoom(true);

    const formattedCode = (code || '').toUpperCase().trim().replace(/[^A-Z0-9]/g, '');
    if (!formattedCode || formattedCode.length !== 4) {
      socket.emit('room:error', {
        message: 'Mã phòng phải gồm đúng 4 ký tự chữ và số!',
      });
      return;
    }

    const rooms = loadRooms();
    let room = rooms[formattedCode];

    if (!room) {
      room = {
        code: formattedCode,
        name: `Phòng đấu ${formattedCode}`,
        hostId: socket.id,
        duration: 30,
        status: 'lobby',
        createdAt: Date.now(),
        players: {},
      };
      rooms[formattedCode] = room;
    }

    if (room.emptyTimer) {
      clearTimeout(room.emptyTimer);
      delete room.emptyTimer;
    }

    const currentPlayers = Object.keys(room.players);
    if (currentPlayers.length >= 2 && !room.players[socket.id]) {
      socket.emit('room:error', {
        message: `Phòng "${room.name || formattedCode}" đã đủ 2 người chơi (tối đa 2 người đối kháng).`,
      });
      return;
    }

    room.players[socket.id] = {
      id: socket.id,
      username: (username || '').trim() || (currentPlayers.length === 0 ? 'Chủ Phòng' : 'Người Thách Đấu'),
      score: 0,
      combo: 0,
      maxCombo: 0,
      reps: 0,
      invalidReps: 0,
      isReady: false,
      isCalibrated: false,
      dArm: 0,
      dTorso: 0,
    };

    if (!room.hostId || !room.players[room.hostId]) {
      room.hostId = socket.id;
    }

    saveRooms(rooms);
    currentRoomCode = formattedCode;
    socket.join(formattedCode);

    socket.emit('room:joined', { room, playerId: socket.id, isHost: room.hostId === socket.id });
    io.to(formattedCode).emit('room:updated', { room });
    broadcastRoomList();
  });

  socket.on('room:transfer_host', ({ targetId }: { targetId?: string }) => {
    if (!currentRoomCode) return;
    const rooms = loadRooms();
    const room = rooms[currentRoomCode];
    if (!room || room.hostId !== socket.id) return;

    const playerIds = Object.keys(room.players);
    const newHostId = targetId && room.players[targetId] ? targetId : playerIds.find((id) => id !== socket.id);
    if (newHostId && room.players[newHostId]) {
      room.hostId = newHostId;
      const newHostUsername = room.players[newHostId]?.username || 'Chủ Phòng';
      console.log(`[Host Manual Transfer] Room ${currentRoomCode}: Host transferred to ${newHostId} (${newHostUsername})`);

      saveRooms(rooms);
      io.to(currentRoomCode).emit('room:host_transferred', {
        newHostId: room.hostId,
        newHostUsername,
        message: `Chủ phòng đã chuyển giao quyền chủ phòng cho ${newHostUsername}!`,
      });
      io.to(currentRoomCode).emit('room:updated', { room });
      broadcastRoomList();
    }
  });

  socket.on('room:set_duration', ({ duration }: { duration: number }) => {
    if (!currentRoomCode) return;
    const rooms = loadRooms();
    const room = rooms[currentRoomCode];
    if (!room || room.hostId !== socket.id) return;
    room.duration = duration;
    saveRooms(rooms);
    io.to(currentRoomCode).emit('room:updated', { room });
  });

  socket.on('player:calibrated', ({ dArm, dTorso }: { dArm: number; dTorso: number }) => {
    if (!currentRoomCode) return;
    const rooms = loadRooms();
    const room = rooms[currentRoomCode];
    if (!room || !room.players[socket.id]) return;
    room.players[socket.id].isCalibrated = true;
    room.players[socket.id].dArm = dArm;
    room.players[socket.id].dTorso = dTorso;
    saveRooms(rooms);
    io.to(currentRoomCode).emit('room:updated', { room });
  });

  socket.on('player:ready', ({ isReady }: { isReady: boolean }) => {
    if (!currentRoomCode) return;
    const rooms = loadRooms();
    const room = rooms[currentRoomCode];
    if (!room || !room.players[socket.id]) return;
    room.players[socket.id].isReady = isReady;
    saveRooms(rooms);
    io.to(currentRoomCode).emit('room:updated', { room });
  });

  socket.on('room:start_game', () => {
    if (!currentRoomCode) return;
    const rooms = loadRooms();
    const room = rooms[currentRoomCode];
    if (!room) return;

    // Self-healing host check: If hostId is invalid or not in room.players, assign first player
    if (!room.players[room.hostId]) {
      const pids = Object.keys(room.players);
      if (pids.length > 0) {
        room.hostId = pids[0];
        saveRooms(rooms);
        io.to(currentRoomCode).emit('room:host_transferred', {
          newHostId: room.hostId,
          newHostUsername: room.players[room.hostId]?.username || 'Chủ Phòng',
          message: 'Tự động khôi phục quyền chủ phòng cho người chơi.',
        });
        io.to(currentRoomCode).emit('room:updated', { room });
      }
    }

    if (room.hostId !== socket.id) {
      socket.emit('room:error', {
        message: 'Chỉ chủ phòng mới có quyền bấm Bắt Đầu trận đấu!',
      });
      return;
    }

    const playersList = Object.values(room.players);
    if (playersList.length < 2) {
      socket.emit('room:error', {
        message: 'Cần đủ 2 người chơi trong phòng để bắt đầu trận đấu đối kháng!',
      });
      return;
    }

    const allReady = playersList.every((p) => p.isReady);
    if (!allReady) {
      socket.emit('room:error', {
        message: 'Cả hai người chơi đều phải bấm SẴN SÀNG trước khi chủ phòng bấm Bắt Đầu!',
      });
      return;
    }

    room.status = 'countdown';
    saveRooms(rooms);
    const roomCodeTarget = currentRoomCode;
    io.to(roomCodeTarget).emit('room:countdown_start', { startsIn: 3 });

    setTimeout(() => {
      const rMap = loadRooms();
      const r = rMap[roomCodeTarget];
      if (r && r.status === 'countdown') {
        io.to(roomCodeTarget).emit('room:countdown_tick', { count: 2 });
      }
    }, 1000);

    setTimeout(() => {
      const rMap = loadRooms();
      const r = rMap[roomCodeTarget];
      if (r && r.status === 'countdown') {
        io.to(roomCodeTarget).emit('room:countdown_tick', { count: 1 });
      }
    }, 2000);

    setTimeout(() => {
      const rMap = loadRooms();
      const activeRoom = rMap[roomCodeTarget];
      if (activeRoom && activeRoom.status === 'countdown') {
        activeRoom.status = 'playing';
        activeRoom.startedAt = Date.now();
        saveRooms(rMap);
        io.to(roomCodeTarget).emit('room:countdown_tick', { count: 0 });
        io.to(roomCodeTarget).emit('room:game_start', {
          duration: activeRoom.duration,
          startedAt: activeRoom.startedAt,
        });
      }
    }, 3000);
  });

  socket.on('camera:frame', ({ frame }: { frame: string }) => {
    if (!currentRoomCode) return;
    socket.to(currentRoomCode).emit('camera:frame', {
      senderId: socket.id,
      frame,
    });
  });

  socket.on(
    'game:rep_update',
    (data: {
      score: number;
      combo: number;
      reps: number;
      invalidReps: number;
      activeHand?: 'left' | 'right';
      reason?: string;
    }) => {
      if (!currentRoomCode) return;
      const rooms = loadRooms();
      const room = rooms[currentRoomCode];
      if (!room || !room.players[socket.id]) return;

      const player = room.players[socket.id];
      player.score = data.score;
      player.combo = data.combo;
      player.maxCombo = Math.max(player.maxCombo, data.combo);
      player.reps = data.reps;
      player.invalidReps = data.invalidReps;
      saveRooms(rooms);

      socket.to(currentRoomCode).emit('game:peer_update', {
        playerId: socket.id,
        ...data,
        timestamp: Date.now(),
      });
    }
  );

  socket.on('game:over', () => {
    if (!currentRoomCode) return;
    const rooms = loadRooms();
    const room = rooms[currentRoomCode];
    if (!room) return;

    room.status = 'gameover';
    saveRooms(rooms);
    io.to(currentRoomCode).emit('room:game_over', { room });
  });

  socket.on('game:rematch', () => {
    if (!currentRoomCode) return;
    const rooms = loadRooms();
    const room = rooms[currentRoomCode];
    if (!room) return;

    room.status = 'lobby';
    for (const pid of Object.keys(room.players)) {
      room.players[pid].score = 0;
      room.players[pid].combo = 0;
      room.players[pid].reps = 0;
      room.players[pid].invalidReps = 0;
      room.players[pid].isReady = false;
    }

    saveRooms(rooms);
    io.to(currentRoomCode).emit('room:updated', { room });
  });

  socket.on('webrtc:signal', ({ targetId, signal }: { targetId?: string; signal: any }) => {
    if (!currentRoomCode) return;
    const rooms = loadRooms();
    const room = rooms[currentRoomCode];
    if (!room) return;

    if (targetId) {
      io.to(targetId).emit('webrtc:signal', {
        senderId: socket.id,
        signal,
      });
    } else {
      socket.to(currentRoomCode).emit('webrtc:signal', {
        senderId: socket.id,
        signal,
      });
    }
  });

  socket.on('disconnect', () => {
    leaveCurrentRoom(false);
  });
});

async function startServer() {
  const distPath = path.join(__dirname, 'dist');
  const distIndexPath = path.join(distPath, 'index.html');
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(distIndexPath);

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);

    // Fallback in case a route isn't handled by vite.middlewares
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        const indexHtmlPath = path.join(__dirname, 'index.html');
        if (fs.existsSync(indexHtmlPath)) {
          const rawHtml = fs.readFileSync(indexHtmlPath, 'utf-8');
          const transformedHtml = await vite.transformIndexHtml(url, rawHtml);
          res.status(200).set({ 'Content-Type': 'text/html' }).end(transformedHtml);
        } else {
          next();
        }
      } catch (e) {
        next(e);
      }
    });
  } else {
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(distIndexPath);
    });
  }

  server.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[King of aura] Server running on port ${PORT} (${isProd ? 'production' : 'vite-middleware dev mode'})`);
  });
}

startServer().catch((err) => {
  console.error('[King of aura] Failed to start server:', err);
});
